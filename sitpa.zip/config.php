<?php
$host = mysqli_connect("localhost","root","");
$db_selected = mysqli_select_db($host, 'sitpa');

?>